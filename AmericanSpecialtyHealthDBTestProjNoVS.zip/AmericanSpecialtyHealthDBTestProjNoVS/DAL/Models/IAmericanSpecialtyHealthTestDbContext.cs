﻿using Microsoft.EntityFrameworkCore;

namespace DAL.Models
{
    //TODO: improve
    public interface IAmericanSpecialtyHealthTestDbContext
    {
        DbSet<Employee> Employees { get; set; }
        DbSet<Manager> Managers { get; set; }
        DbSet<Person> People { get; set; }
        DbSet<Supervisor> Supervisors { get; set; }
    }
}