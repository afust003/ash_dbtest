﻿using System;
using System.Collections.Generic;

namespace DAL.Models;

public partial class Supervisor
{
    public int SupervisorId { get; set; }

    public decimal AnnualSalary { get; set; }

    public virtual Person SupervisorNavigation { get; set; } = null!;
}
