﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace DAL.Models;

public partial class AmericanSpecialtyHealthTestDbContext : DbContext, IAmericanSpecialtyHealthTestDbContext
{
    public AmericanSpecialtyHealthTestDbContext()
    {
    }

    public AmericanSpecialtyHealthTestDbContext(DbContextOptions<AmericanSpecialtyHealthTestDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Employee> Employees { get; set; }

    public virtual DbSet<Manager> Managers { get; set; }

    public virtual DbSet<Person> People { get; set; }

    public virtual DbSet<Supervisor> Supervisors { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=localhost\\SQLEXPRESS;Database=AmericanSpecialtyHealthTestDB;Trusted_Connection=True;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Employee>(entity =>
        {
            entity.Property(e => e.EmployeeId)
                .ValueGeneratedNever()
                .HasColumnName("EmployeeID");
            entity.Property(e => e.PayPerHour).HasColumnType("decimal(5, 2)");

            entity.HasOne(d => d.EmployeeNavigation).WithOne(p => p.Employee)
                .HasForeignKey<Employee>(d => d.EmployeeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Employees_People");
        });

        modelBuilder.Entity<Manager>(entity =>
        {
            entity.Property(e => e.ManagerId)
                .ValueGeneratedNever()
                .HasColumnName("ManagerID");
            entity.Property(e => e.AnnualSalary).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.MaxExpenseAmount).HasColumnType("decimal(10, 2)");

            entity.HasOne(d => d.ManagerNavigation).WithOne(p => p.Manager)
                .HasForeignKey<Manager>(d => d.ManagerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Managers_People");
        });

        modelBuilder.Entity<Person>(entity =>
        {
            entity.HasKey(e => e.PeopleId);

            entity.Property(e => e.PeopleId)
                .ValueGeneratedNever()
                .HasColumnName("PeopleID");
            entity.Property(e => e.FirstName)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.LastName)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Supervisor>(entity =>
        {
            entity.Property(e => e.SupervisorId)
                .ValueGeneratedNever()
                .HasColumnName("SupervisorID");
            entity.Property(e => e.AnnualSalary).HasColumnType("decimal(10, 2)");

            entity.HasOne(d => d.SupervisorNavigation).WithOne(p => p.Supervisor)
                .HasForeignKey<Supervisor>(d => d.SupervisorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Supervisors_People");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
