﻿using System;
using System.Collections.Generic;

namespace DAL.Models;

public partial class Manager
{
    public int ManagerId { get; set; }

    public decimal AnnualSalary { get; set; }

    public decimal MaxExpenseAmount { get; set; }

    public virtual Person ManagerNavigation { get; set; } = null!;
}
