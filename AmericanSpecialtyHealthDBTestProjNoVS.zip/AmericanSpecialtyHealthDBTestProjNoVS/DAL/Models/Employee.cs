﻿using System;
using System.Collections.Generic;

namespace DAL.Models;

public partial class Employee
{
    public int EmployeeId { get; set; }

    public decimal PayPerHour { get; set; }

    public virtual Person EmployeeNavigation { get; set; } = null!;
}
