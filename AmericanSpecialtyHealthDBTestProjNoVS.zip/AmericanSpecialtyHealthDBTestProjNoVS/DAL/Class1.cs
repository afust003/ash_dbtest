﻿namespace DAL
{
    public class Class1
    {

    }
}