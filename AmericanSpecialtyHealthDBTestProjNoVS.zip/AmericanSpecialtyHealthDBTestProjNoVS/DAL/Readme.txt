﻿Scaffold-DbContext "Server=localhost\SQLEXPRESS;Database=AmericanSpecialtyHealthTestDB;Trusted_Connection=True;TrustServerCertificate=True;" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Models

