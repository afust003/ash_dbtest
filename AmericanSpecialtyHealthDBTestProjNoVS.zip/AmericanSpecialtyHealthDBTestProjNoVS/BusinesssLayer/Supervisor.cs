﻿using BusinesssLayer;
using System;
using System.Collections.Generic;

namespace BusinessLayer
{

    public partial class Supervisor: IEmployee
    {
        public int SupervisorId { get; set; }

        public decimal AnnualSalary { get; set; }

        //public virtual Person SupervisorNavigation { get; set; } = null!;
    }
}