﻿using BusinesssLayer;
using System;
using System.Collections.Generic;

namespace BusinessLayer
{
    public partial class Employee: IEmployee
    {
        public int EmployeeId { get; set; }

        public decimal PayPerHour { get; set; }

        public virtual Person EmployeeNavigation { get; set; } = null!;
    }

}