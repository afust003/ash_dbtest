﻿using BusinesssLayer;
using System;
using System.Collections.Generic;

namespace BusinessLayer
{

    public partial class Manager: IEmployee
    {
        public int ManagerId { get; set; }

        public decimal AnnualSalary { get; set; }

        public decimal MaxExpenseAmount { get; set; }

        //public virtual Person ManagerNavigation { get; set; } = null!;
    }
}