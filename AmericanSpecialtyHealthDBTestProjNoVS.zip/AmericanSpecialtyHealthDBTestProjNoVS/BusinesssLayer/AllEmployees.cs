﻿using BusinessLayer;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinesssLayer
{
    public partial class AllEmployees
    {
        public IEnumerable<Employee> Employees { get; set; }
        public IEnumerable<Supervisor> Supervisors { get; set; }
        public IEnumerable<Manager> Managers { get; set; }
    }
}
