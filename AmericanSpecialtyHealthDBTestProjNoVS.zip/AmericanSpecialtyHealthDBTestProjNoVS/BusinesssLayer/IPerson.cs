﻿namespace BusinessLayer
{
    public interface IPerson
    {
    }
}