using BusinessLayer;
using BusinesssLayer;
using DAL.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Person = BusinessLayer.Person;

namespace AmericanSpecialtyHealthDBTestProj.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EmployeeController : ControllerBase
    {
        private readonly AmericanSpecialtyHealthTestDbContext _context;

        //    private static readonly string[] Summaries = new[]
        //    {
        //    "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        //};

        //private readonly ILogger<WeatherForecastController> _logger;

        public EmployeeController(AmericanSpecialtyHealthTestDbContext context /*ILogger<WeatherForecastController> logger*/)
        {
            _context = context;
            //_logger = logger;
        }

        [HttpGet("GetAllEmployees")]
        public async Task<BusinesssLayer.AllEmployees> GetAllEmployees()
        {
            // Make 3 separate DB query calls within a single transaction ... combine the results
            // TODO: improve
            var employees = await _context.Employees.ToListAsync();
            var supervisors = await _context.Supervisors.ToListAsync();
            var managers = await _context.Managers.ToListAsync();

            // TODO: in this function we would use AutoMapper to convert from DAL to BL!
            BusinesssLayer.AllEmployees result = ConvertAndCombineEmployeeQueryResults(employees, supervisors, managers);

            return result;
        }

        [HttpPost]
        public async Task<ActionResult<Person>> AddNewEmployee(IAddEmployee iAddEmployee)
        {
            if (iAddEmployee == null)
            {
                return BadRequest();
            }

            // TODO: convert BL IAddEmployee to EFCore Entity model, decide which employee type it is, and add the appropriate
            // EF "model" to the database via something like this in a single transcation:
            // Note: we need to convert from BL to DAL "entity" model.
            // _context.People.Add(thePeople);
            // _context.Employee.Add(theEmployee);
            // await _context.SaveChangesAsync();
            ParseIAddEmployeeAndPerformDBInsertOperationIntoMultipleTables(iAddEmployee, out Person newlyAddedPerson);
            //Finally, return the Person object just inserted to the caller!
            return Ok(newlyAddedPerson);
            
        }
        private void ParseIAddEmployeeAndPerformDBInsertOperationIntoMultipleTables(IAddEmployee iAddEmployee, out Person newlyAddedPerson)
        {
            throw new NotImplementedException();
        }



        //[HttpPut("AddEmployee")]
        //public async Task<BusinesssLayer.AllEmployees> GetAllEmployees()
        //{
        //    // Make 3 separate DB query calls within a single transaction ... combine the results
        //    // TODO: improve
        //    var employees = await _context.Employees.ToListAsync();
        //    var supervisors = await _context.Supervisors.ToListAsync();
        //    var managers = await _context.Managers.ToListAsync();

        //    // TODO: in this function we would use AutoMapper to convert from DAL to BL!
        //    BusinesssLayer.AllEmployees result = ConvertAndCombineEmployeeQueryResults(employees, supervisors, managers);

        //    return result;
        //}

        private AllEmployees ConvertAndCombineEmployeeQueryResults(List<DAL.Models.Employee> employees, List<DAL.Models.Supervisor> supervisors, List<DAL.Models.Manager> managers)
        {
            // TODO: in this function we would use AutoMapper to convert from DAL to BL!
            throw new NotImplementedException("implement and improve this!");
        }
    }
}