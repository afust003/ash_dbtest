using AmericanSpecialtyHealthDBTestProj.Controllers;
using Azure.Identity;
using BusinesssLayer;
using DAL.Models;
using Moq;

namespace WebApiUnitTests
{
    public class Tests
    {


        [SetUp]
        public void Setup()
        {
            // nothing to do.
        }

        [Test]
        public void AddResularEmployeeSucceeds()
        {
            // Arrange
            Mock<IAmericanSpecialtyHealthTestDbContext> mockedContext = new Mock<IAmericanSpecialtyHealthTestDbContext>();

            IAddEmployee iEmployeeToAdd = null;//TODO: setup happy path

            // Act
            //TODO: refactor to use proper IContext
            EmployeeController cut = new EmployeeController(mockedContext.Object);
            // Assert
            var result = cut.AddNewEmployee(iEmployeeToAdd);
            Assert.IsNotNull(result);
            //TODO: better assertion.
        }

        [Test]
        public void AddRegularEmployeeFails()
        {
            //TODO: rainy day
        }
    }
}